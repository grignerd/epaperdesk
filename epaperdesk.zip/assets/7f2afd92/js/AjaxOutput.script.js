

function serverValidation(response) {
    
    if (response.authentication === true) {

        if (response.authorization === true) {
            if (response.error === false) {
                if (response.validation_status === true) {
                    return true;
                } else {
                    alert("Form validation failed.\nErrors :\n" + response.validation_errors);
                    return false;
                }
            } else {
                alert(response.error);
                return false;
            }
        } else {
            alert("You are unauthorized to perform this action");
            return false;
        }
    } else if (response.authentication === false) {
        //Refresh the page to display login		 
        window.location = window.location.href;
    }
}

function resetForm(selector) {
    $(selector).each(function() {
        this.reset();
    });
    $(selector + " input[type=hidden]").val("");
}

function populateForm(formselector, data, prefix) {
    if (prefix == undefined) {
        prefix = "";
    }
    prefix = "#" + prefix + "_";
    $.each(data, function(name, value) {
        $(prefix + name).val(value);
    });
}

function showError(textStatus, errorThrown) {
    alert("Error : " + errorThrown + "\nStatus : " + textStatus);
}

