
function htmlEncode(value) {
    return $('<div/>').text(value).html();
}

function htmlDecode(value) {
    return $('<div/>').html(value).text();
}


function popupWindow(pageURL, title, w, h) {
    var left = (screen.width / 2) - (w / 2);
    var top = (screen.height / 2) - (h / 2);
    window.open(pageURL, title, 'menubar=1, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
}

function formatDate(unixTimestamp) {
    var dt = new Date(unixTimestamp * 1000);
    var date = dt.getDate();
    var month = dt.getUTCMonth();
    var year = dt.getFullYear();
    return date + "-" + month + "-" + year;
}
;

String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
};
function formatNumber(value, decimals) {
    return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}
