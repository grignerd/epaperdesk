<!DOCTYPE html>
<html>
<head>
	<title>404</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	<div>
		<p>Page Not Found</p>
	</div>


<style type="text/css">
body{padding:0;margin:0;font-weight:700;width:100%;height:100%;color:#000; background: #212121}
html{padding:0;margin:0;font-weight:700}
img{width:100%;border:none}
p{color: #fff; position: relative; top: 25%;}
</style>

</body>
</html>