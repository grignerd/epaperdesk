<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
</head>
<body>
<?php
define ('hostnameorservername','localhost');
define ('serverusername','epaperdeskdemo');
define ('serverpassword','%<^@7D4MaY');
define ('databasenamed','epaperdeskdemo_db');
global $con;
$con = mysqli_connect(hostnameorservername,serverusername,serverpassword) or die('Sorry , Connection could not be made to the Server. Please report this system error at <font color="blue">info@flixweb.in</font>');
mysqli_select_db($con,databasenamed) or die('Sorry ,Connection could not be made to the server. Please report this system error at <font color="blue">info@flixweb.in</font>');

//definde
$base_url = '/uploads/epaper/';

date_default_timezone_set('Asia/Kolkata');

if(isset($_GET['date_s']) && !empty($_GET['date_s']) && isset($_GET['page_s']) && !empty($_GET['page_s']) && isset($_GET['cat']) && !empty($_GET['cat'])){

    $urlid    = htmlspecialchars(trim($_GET['date_s']));
    $page_no  = htmlspecialchars(trim($_GET['page_s']));
    $category = htmlspecialchars(trim($_GET['cat']));
  

$select_post_date = "select ed_date, ed_id, cat_id from epaper_editions where ed_date='$urlid' and cat_id='$category'";
$run_posts_date = mysqli_query($con , $select_post_date);
$row_date =mysqli_fetch_array($run_posts_date);
    $findDate =$row_date['ed_id'];

$select_posts = "select pg_order, pg_id, pg_file  from epaper_pages where ed_id='$findDate' and pg_order='$page_no'";
$run_posts = mysqli_query($con , $select_posts);
$row=mysqli_fetch_array($run_posts);
    $numCount = mysqli_num_rows($run_posts);
    $pg_file =$row['pg_file'];

    if($numCount=='0'){
      header("Location: error.php");
    }else{
      //echo '<meta http-equiv="refresh" content="0; url='.$base_url.'/'.$pg_file.'">';
      echo '<title>'.$base_url.'/'.$pg_file.'</title>';
    }

}else{
  
} 
?>
<div style="width: 100%; height: 100%">
  <img src="<?= $base_url ?>/<?= $pg_file ?>">
</div>
<style type="text/css">
body{padding:0;margin:0;font-weight:700;width:100%;height:100%;color:#000; background: #212121}
html{padding:0;margin:0;font-weight:700}
img{width:100%;border:none}
</style>

</body>
</html>